import { View, Text, Button } from 'react-native'
import React from 'react';
 
const HomePage = (props) => {

  return (
  <>
    <Text>dsfsfs</Text><Button title='go' onPress={() =>
      props.navigation.navigate("DetailsPage")} ></Button>
      
      <Button title='go' onPress={() =>
        props.navigation.navigate("AddingPage")} ></Button>
        <Button title='go' onPress={() =>
          props.navigation.navigate("LookUpProfilePage")} ></Button>
      
  </>
  )
}

export default HomePage