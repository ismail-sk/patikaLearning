import { View, Text } from 'react-native'
import React from 'react'

const DetailsPage = () => {
  return (
    <View>
      <Text>DetailsPage</Text>
    </View>
  )
}

export default DetailsPage