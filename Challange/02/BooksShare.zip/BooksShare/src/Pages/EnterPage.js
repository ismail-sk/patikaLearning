import { View, Text, Button } from 'react-native'
import React from 'react'

const EnterPage = (props) => {
  return (
    <View>
      <Text>EnterPage</Text>
      <Button title='go' onPress={() => props.navigation.navigate("MainBottomNavPage")} ></Button>
    </View>
  )
}

export default EnterPage