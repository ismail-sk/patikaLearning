import { View, Text,Button } from 'react-native'
import React from 'react';

import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import {createNativeStackNavigator} from '@react-navigation/native-stack';

import HomePage from './HomePage';
import AddingPage from './AddingPage';
import DetailsPage from './DetailsPage';

import FavoritesPage from './FavoritesPage';
import ProfilePage from './ProfilePage'

const Tab = createBottomTabNavigator();
const HomeStack = createNativeStackNavigator();

const HomeWindow = () => {
  return (
  <HomeStack.Navigator>
    <HomeStack.Screen name="HomePage" component={HomePage}/>
    <HomeStack.Screen name="DetailsPage" component={DetailsPage}/>
    <HomeStack.Screen name="LookUpProfilePage" component={ProfilePage} />
    <HomeStack.Screen name="AddingPage" component={AddingPage} />
  </HomeStack.Navigator>
  )
}

const MainPage = () => {
  return (
    <Tab.Navigator>
      <Tab.Screen name="HomeW" component={HomeWindow} />
      <Tab.Screen name="My Favorites" component={FavoritesPage} />
      <Tab.Screen name="My Profile" component={ProfilePage} />

    </Tab.Navigator>
  )
}

export default MainPage