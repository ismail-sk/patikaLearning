import { View, Text } from 'react-native'
import React from 'react'

const FavoritesPage = () => {
  return (
    <View>
      <Text>FavoritesPage</Text>
    </View>
  )
}

export default FavoritesPage