import { View, Text } from 'react-native'
import React from 'react'

const ProfilePage = () => {
  return (
    <View>
      <Text>ProfilePage</Text>
    </View>
  )
}

export default ProfilePage;