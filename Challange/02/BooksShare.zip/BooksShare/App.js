import React from 'react';
import {
  SafeAreaView,
  ScrollView,
  
  Text,
} from 'react-native';

import EnterPage from './src/Pages/EnterPage';
import MainPage from './src/Pages/MainPage';

import { NavigationContainer } from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';

const App = () =>{

  const Stack = createNativeStackNavigator();

  return (
    <NavigationContainer>
        <Stack.Navigator>

          <Stack.Screen name='FirstScreenPage' component={EnterPage}
          options={{
            title:'the login',
            headerTitleAlign:'center',
            headerTitleStyle:{color:'white',fontWeight:'600',fontSize:32},
            headerStyle:{backgroundColor:'#53a8b6'},//#61c0bf
            headerTintColor:'white'
          }}/>
          
          <Stack.Screen name='MainBottomNavPage' component={MainPage}
          options={{
            title:'main',
            headerTitleAlign:'center',
            headerTitleStyle:{color:'white',fontWeight:'600',fontSize:32},
            headerStyle:{backgroundColor:'#61c09f'},
            headerTintColor:'white'
          }}/>
          </Stack.Navigator>
    </NavigationContainer>
  );
};

export default App;
